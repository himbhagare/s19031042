#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <math.h>

static QImage img(500,500,QImage::Format_RGB888);
static QRgb bgColor(qRgb(0,0,0));

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->display->setPixmap(QPixmap::fromImage(img));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::dda_algo(int x1,int y1,int x2,int y2){
    QRgb value;
    value=qRgb(230,230,0);
    int l;
    if(abs(x2-x1)>=abs(y2-y1)){
        l=abs(x2-x1);
    }
    else{
        l=abs(y2-y1);
    }
    float dx=float(x2-x1)/float (l);
    float dy=float(y2-y1)/float (l);
    float x=x1;
    float y=y1;
    int i=1;
    while(i<l){
        img.setPixel(x,y,value);
        x=x+dx;
        y=y+dy;
        i++;
    }
}


void MainWindow::breshnam(int xc,int yc, int r){
    QRgb value;
    value=qRgb(0,255,255);
    float x=0;
    float y=r;
    float d=3-2*r;
    while(x<=y){
        img.setPixel(y+xc,x+yc,value);
        img.setPixel(x+xc,y+yc,value);
        img.setPixel(-x+xc,y+yc,value);
        img.setPixel(-y+xc,x+yc,value);
        img.setPixel(-y+xc,-x+yc,value);
        img.setPixel(-x+xc,-y+yc,value);
        img.setPixel(x+xc,-y+yc,value);
        img.setPixel(y+xc,-x+yc,value);
        if(d<0){
            d=d+4*x+6;
        }
        else{
            d=d+4*(x-y)+10;
            y=y-1;
        }
        x=x+1;
    }
}



void MainWindow::on_ddaline_clicked()
{
    int x1=ui->plainTextEdit->toPlainText().toInt();
    int y1=ui->plainTextEdit_2->toPlainText().toInt();
    int x2=ui->plainTextEdit_3->toPlainText().toInt();
    int y2=ui->plainTextEdit_4->toPlainText().toInt();
    dda_algo(x1,y1,x2,y2);
    ui->display->setPixmap(QPixmap::fromImage(img));
    ui->display->show();
}


void MainWindow::on_breshnam_clicked()
{
    int xc=ui->plainTextEdit_5->toPlainText().toInt();
    int yc=ui->plainTextEdit_6->toPlainText().toInt();
    int r=ui->plainTextEdit_7->toPlainText().toInt();
    breshnam(xc,yc,r);
    ui->display->setPixmap(QPixmap::fromImage(img));
    ui->display->show();
}


void MainWindow::on_create_clicked()
{

    int xc=ui->plainTextEdit_5->toPlainText().toInt();
    int yc=ui->plainTextEdit_6->toPlainText().toInt();
    int R=ui->plainTextEdit_7->toPlainText().toInt();
    int s=0.866*R;
    int r=0.5*R;
    dda_algo(xc,yc-R,xc+s,yc+r);
    dda_algo(xc,yc-R,xc-s,yc+r);
    dda_algo(xc-s,yc+r,xc+s,yc+r);
    breshnam(xc,yc,R);
    breshnam(xc,yc,r);
    ui->display->setPixmap(QPixmap::fromImage(img));
}


void MainWindow::on_clear_clicked()
{
    img.fill(bgColor);
    ui->display->setPixmap(QPixmap::fromImage(img));
}

