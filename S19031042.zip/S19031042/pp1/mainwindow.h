#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_ddaline_clicked();

    void on_breshnam_clicked();

    void on_create_clicked();

    void on_clear_clicked();
    void dda_algo(int x1,int y1,int x2,int y2);
    void breshnam(int xc,int yc, int r);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
