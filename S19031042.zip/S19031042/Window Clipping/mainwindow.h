#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE

class point{
    float x;
    float y;
    int outcode = 0;
    friend class MainWindow;
};

namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void draw_window();
    void setOutcode(point &p);
    int checkOutcode(point p1, point p2);
    void dda(float x1, float y1, float x2, float y2, uint value);

protected slots:
    void mousePressEvent(QMouseEvent *event);

private slots:
    void on_window_clicked();

    void on_color_clicked();

    void on_window_color_clicked();

    void on_draw_line_clicked();

    void on_clip_line_clicked();

private:
    Ui::MainWindow *ui;

};
#endif // MAINWINDOW_H
